﻿using data;
using Lab4.Models;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;

namespace Laboratorium_3___App.Models
{
    public class EFContactService : IContactService
    {
        private readonly AppDbContext _context;
        public EFContactService(AppDbContext context)
        {
            _context = context;
        }
        public void Add(Contact contact)
        {
            _context.Contacts.Add(ContactMapper.ToEntity(contact));
            _context.SaveChanges();
        }

        public int Add(Lab4.Models.Contact contact)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public void DeleteById(int id)
        {
            var find = _context.Contacts.Find(id);
            if (find is not null)
            {
                _context.Contacts.Remove(find);
            }

        }
        public List<Contact> FindAll()
        {
            return _context.Contacts.Select(e => ContactMapper.FromEntity(e)).ToList();
        }
        public Contact? FindById(int id)
        {
            var find = _context.Contacts.Find(id);
            return find is not null ? ContactMapper.FromEntity(find) : null;
        }
        public void Update(Contact contact)
        {
            var entity = ContactMapper.ToEntity(contact);
            _context.Contacts.Update(entity);
            _context.SaveChanges();

        }

        public void Update(Lab4.Models.Contact contact)
        {
            throw new NotImplementedException();
        }

        List<Lab4.Models.Contact> IContactService.FindAll()
        {
            throw new NotImplementedException();
        }

        Lab4.Models.Contact? IContactService.FindById(int id)
        {
            throw new NotImplementedException();
        }
    }
}