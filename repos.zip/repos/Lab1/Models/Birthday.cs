﻿namespace Lab1.Models
{
    public class Birthday
    {
        public int Id { get; set; }
        public string Imie { get; set; }
        public int Rok { get; set; }
    }
}
