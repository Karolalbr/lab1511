﻿namespace Lab1.Models
{
    public class Dane
    {

        public int Id { get; set; }
        public string Nazwisko { get; set; }
        public string Imie { get; set; }

    }
}
