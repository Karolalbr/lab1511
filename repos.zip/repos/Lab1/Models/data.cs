﻿namespace Lab1.Models
{
    public class Data
    {
        public int pierwsza { get; set; }
        public int druga { get; set; }
        public char znak { get; set; }
    }
}
