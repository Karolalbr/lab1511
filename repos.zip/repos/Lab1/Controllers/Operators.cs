﻿namespace Lab1.Controllers
{
    public class Operators
    {
       
       
    }
}