﻿namespace Lab4.Models
{
    public interface IDateTimeProvider
    {
        DateTime GetDate();
    }
}
