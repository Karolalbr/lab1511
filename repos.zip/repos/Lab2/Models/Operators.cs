﻿namespace Lab2.Models
{
    public enum Operators {
    Add, Sub, Mul, Div
    }

}
